WOHMaker, a custom event creation helper for World of Horror.
By Dae

Site: https://github.com/AlejandroRepo/WOHMakerEV
WOH Discord: https://discordapp.com/invite/bEPAtBY

If you have any feedback or technical issue you can contact me through discord using @Dae

Don't delete de 'jre' folder unless you have a Java11 JDK installed elsewhere!