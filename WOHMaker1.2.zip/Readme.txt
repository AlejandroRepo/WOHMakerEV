WOHMaker, a custom event tool for World of Horror.
By Dae.


WINDOWS: Run 'Launch.WOHMaker.bat' to start the program.
UNIX/MACOS launchers still not available :(

Latest version in : https://github.com/AlejandroRepo/WOHMakerEV
Support: https://discord.com/channels/324155954059018240/690927237163384872